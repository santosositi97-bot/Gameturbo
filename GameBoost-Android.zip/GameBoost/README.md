# Game Boost (Android)

## Cara build
1. Buka folder ini di Android Studio (Koala atau lebih baru) lalu tunggu Gradle sync.
2. Sambungkan HP (debugging USB aktif) dan tekan Run.
3. Saat pertama dipakai, beri izin yang diminta: tampil di atas aplikasi lain, Jangan Ganggu, ubah setelan, notifikasi.

## Fitur yang bekerja nyata
- RAM booster: menutup proses latar belakang aplikasi non-sistem dan menampilkan RAM yang lega.
- Overlay FPS meter yang bisa digeser: refresh rate layar, RAM, suhu dan level baterai.
- Crosshair overlay: 4 gaya, 5 warna, ukuran bisa diatur, tampil di atas game.
- Mode game: blokir notifikasi, kecerahan maksimal, layar tetap menyala.
- WiFi: kecepatan link, kekuatan sinyal, tes ping, mode latensi rendah.

## Batasan Android
- FPS game lain tidak bisa dibaca oleh aplikasi biasa. Angka "Hz" adalah refresh rate layar.
- Pengaturan grafik per game (resolusi, kualitas) hanya bisa dilakukan oleh game itu sendiri.
- Suhu CPU/GPU dan beban CPU tidak tersedia untuk aplikasi biasa (hanya suhu baterai).
- Aplikasi tidak bisa mengganti kanal WiFi atau mematikan/menyalakan WiFi di Android 10 ke atas.

## Dapat APK tanpa Android Studio
1. Buat repositori baru di GitHub, lalu unggah seluruh isi folder ini (termasuk folder .github).
2. Buka tab Actions, tunggu workflow "Build APK" selesai (sekitar 5 menit).
3. Buka hasil run-nya, unduh artifact GameBoost-APK, ekstrak, lalu pasang app-debug.apk di HP.
