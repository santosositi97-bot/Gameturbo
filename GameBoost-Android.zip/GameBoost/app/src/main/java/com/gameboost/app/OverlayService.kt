package com.gameboost.app

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

/** Overlay: FPS meter (kecepatan refresh layar) dan crosshair di atas aplikasi lain. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var meter: TextView? = null
    private var cross: View? = null
    private val h = Handler(Looper.getMainLooper())
    private var frames = 0
    private var hz = 0
    private var running = false

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames++
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }
    private val tick = object : Runnable {
        override fun run() {
            hz = frames; frames = 0
            updateMeter()
            if (running) h.postDelayed(this, 1000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        rebuild()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        clear()
        super.onDestroy()
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("gb", "Game Boost", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "gb")
            .setContentTitle("Game Boost aktif")
            .setContentText("Overlay sedang berjalan")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun clear() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        h.removeCallbacks(tick)
        meter?.let { runCatching { wm.removeView(it) } }
        cross?.let { runCatching { wm.removeView(it) } }
        meter = null; cross = null
    }

    private fun rebuild() {
        val p = getSharedPreferences("gb", MODE_PRIVATE)
        clear()
        if (p.getBoolean("meter", false)) addMeter()
        if (p.getBoolean("cross", false)) addCross()
        if (meter == null && cross == null) { stopSelf(); return }
        if (meter != null) {
            running = true
            frames = 0
            Choreographer.getInstance().postFrameCallback(frameCb)
            h.postDelayed(tick, 1000)
        }
    }

    private fun overlayParams(w: Int, hgt: Int, touchable: Boolean): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            w, hgt,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags, PixelFormat.TRANSLUCENT
        )
    }

    private fun addMeter() {
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setPadding(dp(10), dp(6), dp(10), dp(6))
            setBackgroundColor(Color.argb(204, 10, 12, 17))
            text = "..."
        }
        val lp = overlayParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, true
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(80)
        }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(tv, lp)
                }
            }
            true
        }
        wm.addView(tv, lp)
        meter = tv
    }

    private fun updateMeter() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val ram = 100 - (mi.availMem * 100 / mi.totalMem).toInt()
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        meter?.text = "$hz Hz  RAM $ram%  ${"%.1f".format(temp)}°C  BAT $lvl%"
    }

    private fun addCross() {
        val p = getSharedPreferences("gb", MODE_PRIVATE)
        val v = CrossView(
            this, p.getInt("style", 0), p.getInt("color", Color.parseColor("#00E5FF")),
            dp(p.getInt("size", 24)), dp(p.getInt("th", 3)).toFloat(), dp(p.getInt("gap", 6))
        )
        val lp = overlayParams(dp(200), dp(200), false).apply { gravity = Gravity.CENTER }
        wm.addView(v, lp)
        cross = v
    }

    private class CrossView(
        ctx: Context, val style: Int, val col: Int,
        val size: Int, val th: Float, val gap: Int
    ) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = col; strokeWidth = th; strokeCap = Paint.Cap.ROUND
        }

        override fun onDraw(c: Canvas) {
            val m = width / 2f
            val n = height / 2f
            val s = size / 2f
            val g = gap.toFloat()
            paint.style = Paint.Style.STROKE
            when (style) {
                2 -> { paint.style = Paint.Style.FILL; c.drawCircle(m, n, th * 1.6f, paint) }
                3 -> {
                    c.drawCircle(m, n, s + g / 2, paint)
                    paint.style = Paint.Style.FILL; c.drawCircle(m, n, th, paint)
                }
                else -> {
                    c.drawLine(m + g, n, m + g + s, n, paint)
                    c.drawLine(m - g, n, m - g - s, n, paint)
                    c.drawLine(m, n + g, m, n + g + s, paint)
                    c.drawLine(m, n - g, m, n - g - s, paint)
                    if (style == 1) { paint.style = Paint.Style.FILL; c.drawCircle(m, n, th, paint) }
                }
            }
        }
    }
}
