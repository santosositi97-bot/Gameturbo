package com.gameboost.app

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.net.InetSocketAddress
import java.net.Socket

class MainActivity : Activity() {
    private val red = Color.parseColor("#FF2A44")
    private val bg = Color.parseColor("#0A0C11")
    private val pn = Color.parseColor("#141821")
    private val mb = 1024L * 1024L
    private val prefs by lazy { getSharedPreferences("gb", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var ramTv: TextView
    private lateinit var wifiTv: TextView
    private lateinit var pingTv: TextView
    private var wifiLock: WifiManager.WifiLock? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun tv(t: String, sp: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = sp; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(4))
        }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); setBackgroundColor(red)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    /** Sakelar; [f] mengembalikan false jika perubahan ditolak (mis. izin belum ada). */
    private fun sw(label: String, f: (Boolean) -> Boolean) = Switch(this).apply {
        text = label; setTextColor(Color.WHITE); setPadding(0, dp(10), 0, dp(10))
        var guard = false
        setOnCheckedChangeListener { b, on ->
            if (guard) return@setOnCheckedChangeListener
            if (!f(on)) { guard = true; b.isChecked = !on; guard = false }
        }
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pn)
            setPadding(dp(14), dp(12), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }
        c.addView(tv(title, 18f, red, true))
        root.addView(c)
        return c
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(root) })
        root.addView(tv("GAME BOOST", 30f, Color.WHITE, true))
        root.addView(tv("Performa gaming", 13f, Color.GRAY))

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        buildRam(); buildMode(); buildOverlay(); buildWifi()
    }

    override fun onResume() {
        super.onResume()
        showRam(); showWifi()
    }

    override fun onDestroy() {
        wifiLock?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    /* ---------- RAM ---------- */
    private fun memInfo(): ActivityManager.MemoryInfo {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    }

    private fun showRam() {
        val m = memInfo()
        val used = m.totalMem - m.availMem
        ramTv.text = "Terpakai ${used / mb} / ${m.totalMem / mb} MB (${used * 100 / m.totalMem}%)"
    }

    private fun buildRam() {
        val c = card("RAM BOOSTER")
        ramTv = tv("", 16f); c.addView(ramTv)
        c.addView(btn("BERSIHKAN RAM") {
            val before = memInfo().availMem
            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            packageManager.getInstalledApplications(0)
                .filter { it.packageName != packageName && (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
                .forEach { am.killBackgroundProcesses(it.packageName) }
            Handler(Looper.getMainLooper()).postDelayed({
                val freed = (memInfo().availMem - before) / mb
                showRam()
                toast("RAM lega ${maxOf(freed, 0)} MB")
            }, 1000)
        })
        c.addView(tv("Hanya menutup proses latar belakang aplikasi non-sistem. Android bisa menjalankannya lagi.", 12f, Color.GRAY))
    }

    /* ---------- Mode game ---------- */
    private fun buildMode() {
        val c = card("MODE GAME")
        c.addView(sw("Blokir notifikasi (Jangan Ganggu)") { on ->
            val nm = getSystemService(NotificationManager::class.java)
            if (!nm.isNotificationPolicyAccessGranted) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                toast("Beri izin, lalu coba lagi")
                false
            } else {
                nm.setInterruptionFilter(
                    if (on) NotificationManager.INTERRUPTION_FILTER_NONE
                    else NotificationManager.INTERRUPTION_FILTER_ALL
                )
                true
            }
        })
        c.addView(sw("Kecerahan maksimal") { on ->
            if (!Settings.System.canWrite(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
                toast("Beri izin ubah setelan, lalu coba lagi")
                false
            } else {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, if (on) 255 else 128)
                true
            }
        })
        c.addView(sw("Layar tetap menyala") { on ->
            if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            true
        })
    }

    /* ---------- Overlay: FPS meter + crosshair ---------- */
    private fun refreshOverlay() {
        val i = Intent(this, OverlayService::class.java)
        if (prefs.getBoolean("meter", false) || prefs.getBoolean("cross", false)) startForegroundService(i)
        else stopService(i)
    }

    private fun setOverlay(key: String, on: Boolean): Boolean {
        if (on && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            toast("Izinkan tampil di atas aplikasi lain, lalu coba lagi")
            return false
        }
        prefs.edit().putBoolean(key, on).apply()
        refreshOverlay()
        return true
    }

    private fun buildOverlay() {
        val c = card("OVERLAY")
        c.addView(sw("FPS meter melayang (geser untuk memindah)") { setOverlay("meter", it) })
        c.addView(tv("Menampilkan refresh rate layar, RAM, suhu baterai, dan level baterai.", 12f, Color.GRAY))
        c.addView(sw("Crosshair di tengah layar") { setOverlay("cross", it) })
        val colors = intArrayOf(
            Color.parseColor("#00E5FF"), Color.parseColor("#3DFFA0"), Color.parseColor("#FFC83D"),
            Color.parseColor("#FF2A44"), Color.WHITE
        )
        c.addView(btn("GANTI GAYA CROSSHAIR") {
            prefs.edit().putInt("style", (prefs.getInt("style", 0) + 1) % 4).apply(); refreshOverlay()
        })
        c.addView(btn("GANTI WARNA") {
            val cur = colors.indexOf(prefs.getInt("color", colors[0])).coerceAtLeast(0)
            prefs.edit().putInt("color", colors[(cur + 1) % colors.size]).apply(); refreshOverlay()
        })
        c.addView(tv("Ukuran", 13f, Color.GRAY))
        c.addView(SeekBar(this).apply {
            max = 60; progress = prefs.getInt("size", 24)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) prefs.edit().putInt("size", maxOf(p, 8)).apply()
                }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) { refreshOverlay() }
            })
        })
    }

    /* ---------- WiFi ---------- */
    @Suppress("DEPRECATION")
    private fun showWifi() {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val i = wm.connectionInfo
        wifiTv.text = if (i == null || i.networkId == -1) "Tidak terhubung ke WiFi" else
            "Kecepatan link: ${i.linkSpeed} Mbps\n" +
            "Sinyal: ${i.rssi} dBm (${WifiManager.calculateSignalLevel(i.rssi, 5)}/4)\n" +
            "Frekuensi: ${i.frequency} MHz"
    }

    private fun buildWifi() {
        val c = card("WIFI")
        wifiTv = tv("", 15f); c.addView(wifiTv)
        pingTv = tv("Ping: belum dites", 15f); c.addView(pingTv)
        c.addView(sw("Mode latensi rendah (saat app terbuka)") { on ->
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (on) {
                val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                else WifiManager.WIFI_MODE_FULL_HIGH_PERF
                @Suppress("DEPRECATION")
                wifiLock = wm.createWifiLock(mode, "gameboost").also { it.acquire() }
            } else {
                wifiLock?.takeIf { it.isHeld }?.release()
            }
            true
        })
        c.addView(btn("TES PING") {
            pingTv.text = "Ping: mengukur..."
            Thread {
                val t = ArrayList<Long>()
                repeat(3) {
                    try {
                        val s = System.nanoTime()
                        Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 2000) }
                        t.add((System.nanoTime() - s) / 1_000_000)
                    } catch (e: Exception) { }
                }
                runOnUiThread {
                    pingTv.text = if (t.isEmpty()) "Ping: gagal" else "Ping rata-rata: ${t.average().toInt()} ms"
                }
            }.start()
        })
        c.addView(btn("PANEL INTERNET") {
            startActivity(
                if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                else Intent(Settings.ACTION_WIFI_SETTINGS)
            )
        })
        c.addView(tv("Android tidak mengizinkan aplikasi biasa mengganti kanal atau kecepatan WiFi.", 12f, Color.GRAY))
    }
}
